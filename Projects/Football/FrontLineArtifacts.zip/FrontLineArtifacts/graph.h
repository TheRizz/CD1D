#ifndef GRAPH_H
#define GRAPH_H

#include <QString>
#include <QList>
#include <QDebug>
#include "team.h"
#include "route.h"
#include "graphnode.h"

/**
 * @brief The Graph class, has methods for graph manipulation,
 * DFS
 */
class Graph
{

private:


public:
    int matrix[100][100];
    QList<GraphNode*> nodes;


    public:
        /**
         * @brief Graph - Default constructor
         */
        Graph();

        ~Graph();

        /**
         * @brief addNode - Add a node to the graph
         * @param o - The team to add
         */
        void addNode(Team o);

        /**
         * @brief addEdge - Add an edge
         * @param str1 - Name of node1
         * @param str2 - Name of node2
         * @param dist - Distance of edge
         */
        void addEdge(QString str1, QString str2, int dist);

        /**
         * @brief idOfStr - returns the id of the team with the name s
         * @param s - The name of the team
         * @return - the id of the team with name s
         */
        int idOfStr(QString s);

        /**
         * @brief clearVisited - Clears the visited flag on the graphnodes
         */
        void clearVisited();

        /**
         * @brief DFS - DFS's the graph
         * @param start - Start node
         * @return - a route with the dfs
         */
        Route DFS(QString start);

        /**
         * @brief BFS  -NOT IMPLEMENTED
         */
        Route BFS(QString start);

        /**
         * @brief DFS helper function for program
         */
        QList<GraphNode*> DFS(int id, QList<GraphNode*> cur);


};

#endif // GRAPH_H
