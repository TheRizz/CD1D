/*************************************************************************
 * AUTHOR		: Ryan Martinez
 * STUDENT ID	: 389657
 * Assignment	: 12
 * CLASS		: CS1D
 * SECTION		: MW: 3:30 PM
 * DUE DATE		: 11/23/2016
 ************************************************************************/
#ifndef MST_H_
#define MST_H_
#include "mainwindow.h"
#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <limits.h>
#include "team.h"

using namespace std;
#define V 100

// A utility function to print the constructed MST stored in parent[]
/**
 * @brief printMST - prints the mst for an adjacency matrix
 * @param parent - stores the parent of the current node
 * @param n - current node
 * @param graph - the adjacency matrix
 * @param size - the size of the matrix
 * @param teams - The list of teams
 */
QString printMST(int parent[], int n, int graph[V][V], const int size, QList<Team> teams)
{
   QString print = "";
   int total = 0;
   for (int i = 1; i < size; i++)
   {
      print += teams[parent[i]].getName();
      print += " to ";
      print += teams[i].getName();
      print += " is ";
      print += QString::number(graph[i][parent[i]]);
      print += "\n\n";
      total += graph[i][parent[i]];
   }
   print += "Total Distance: ";
   print += QString::number(total);

   return print;
}

// A function used to find the lowest verticie from the matrix
/**
 * @brief minimum - smallest value
 * @param key - current node
 * @param matrix - matrix storing the bool values
 * @param size - size of the matrix
 * @return  - returns the smallest value
 */
int minimum(int key[], bool matrix[], const int size)
{
   // Initializes the smallest value
   int min = INT_MAX;
   int min_index;

   for (int v = 0; v < size; v++)
    if (matrix[v] == false && key[v] < min)
         min = key[v], min_index = v;

   return min_index;
}

// Function to construct and print MST for a graph represented using adjacency
// matrix representation
/**
 * @brief MST - Minimum Spanning Tree
 * @param graph - graph generated in program
 * @param teams - list of the teams
 * @param size - list of the teams list
 */
QString MST(int graph[V][V], QList<Team> teams, const int size)
{
     int parent[V];
     int key[V];
     bool matrix[V];

     // Initialize all keys as INFINITE
     for (int i = 0; i < size; i++)
        key[i] = INT_MAX, matrix[i] = false;

     // Always include first 1st vertex in MST.
     key[0] = 0;     // Make key 0 so that this vertex is picked as first vertex
     parent[0] = -1; // First node is always root of MST

     // The MST will have V vertices
     for (int count = 0; count < size-1; count++)
     {
        // Pick thd minimum key vertex from the set of vertices
        // not yet included in MST
        int u = minimum(key, matrix, size);

        // Add the picked vertex to the MST Set
        matrix[u] = true;

        // Update key value and parent index of the adjacent vertices of
        // the picked vertex. Consider only those vertices which are not yet
        // included in MST
        for (int v = 0; v < size; v++)

           // graph[u][v] is non zero only for adjacent vertices of m
           // matrix[v] is false for vertices not yet included in MST
           // Update the key only if graph[u][v] is smaller than key[v]
          if (graph[u][v] && matrix[v] == false && graph[u][v] <  key[v])
             parent[v]  = u, key[v] = graph[u][v];
     }

     // print the constructed MST
     return printMST(parent, V, graph, size, teams);
}






#endif /* MST_H_ */
