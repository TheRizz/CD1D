#ifndef DATABASE_H
#define DATABASE_H

#include <QSqlDatabase>
#include <QSqlQuery>
#include <QDebug>

#include "team.h"
#include "souvenir.h"
using namespace std;

struct EdgeInfo
{
    QString first;
    QString second;
    int distance;

    EdgeInfo(QString f, QString s, int d);
};

class Database : public QSqlDatabase
{
public:
    static Database* getInstance();

    ~Database();

    /**
     * @brief addTeam will attempt to store the new team into the database
     * @param newTeam - the team to be add
     * @return a bool representing the success or failure of the query
     */
    bool addTeam(Team newTeam);

    /**
     * @brief updateTeam will attempt to update data thats already been inserted
     * @param team - the team to update
     * @param oldName - in case the teams name has changed
     * @return a bool representing the success or failure of the query
     */
    bool updateTeam(Team team, QString oldName);

    /**
     * @brief getTeam - Gets a team with a name
     * @param name - the name of the team
     * @return - the team
     */
    Team getTeam(QString name);

    /**
     * @brief getAllTeams - Gets all the teams
     * @return A list of all teams
     */
    QList<Team> getAllTeams();

    /**
     * @brief getTotalSeats - Gets all seats in all stadiums
     * @return - The total number of seats for all stadiums
     */
    int getTotalSeats();

    /**
     * @brief addSouvenir - Adds a souvenir
     * @param stadiumName - The name of the stadium that you can buy this souvenir from
     * @param productName - The name of this product
     * @param price - The price of this product
     */
    void addSouvenir(QString stadiumName, QString productName, double price);

    /**
     * @brief getAllSouvenirs - Gets all the souvenirs
     * @return - The list of souvenirs
     */
    QList<Souvenir> getAllSouvenirs();

    /**
     * @brief getAllSouvenirsByTeam - Gets all souvenirs for team t
     * @param team - the team
     * @return - see description
     */
    QList<Souvenir> getAllSouvenirsByTeam(QString team);
    /**
     * @brief getSouvenir - Gets a souvenir with a name
     * @param productName - The name of the product
     * @return  - The souvenir with a name
     */
    Souvenir getSouvenir(QString productName);

    /**
     * @brief setDistance will add a distance to the database between two points
     * @param start - one of the points
     * @param end - the other point
     * @param distance - the distance between the points
     * @return - Whether the query executed succesfully
     */
    bool setDistance(QString start, QString end, float distance);

    /**
     * @brief getDistance will get the distance between two points
     * @param start - the first point
     * @param end - the second point
     * @return the distance between the above two points
     */
    float getDistance(QString start, QString end);

    /**
     * @brief GetConnections - Gets a list of all connections
     * @return - A list of EdgeInfo objects
     */
    QList<EdgeInfo> GetConnections();

    /**
     * @brief exists - Determines whether an edge exisits
     * @param list - The list of edgeinfo
     * @param first - First name
     * @param second - Second name
     * @return - If the edge exsists
     */
    bool exists(QList<EdgeInfo> list, QString first, QString second);

private:
    Database();
    static Database* instance;
};

#endif // DATABASE_H
