var searchData=
[
  ['link',['Link',['../class_link.html',1,'Link'],['../class_link.html#a1918a8473cee40bbed17b8e926cb85d9',1,'Link::Link()'],['../class_link.html#a592bac880e885b5d4270cddf568c73fc',1,'Link::Link(int distance, GraphNode *ptr=nullptr)']]]
];
