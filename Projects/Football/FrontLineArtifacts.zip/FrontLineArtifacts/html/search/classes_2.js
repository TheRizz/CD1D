var searchData=
[
  ['edgeinfo',['EdgeInfo',['../struct_edge_info.html',1,'']]]
];
