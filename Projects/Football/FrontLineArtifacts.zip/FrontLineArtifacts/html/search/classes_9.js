var searchData=
[
  ['team',['Team',['../class_team.html',1,'']]],
  ['teamnamesort',['TeamNameSort',['../struct_team_name_sort.html',1,'']]]
];
