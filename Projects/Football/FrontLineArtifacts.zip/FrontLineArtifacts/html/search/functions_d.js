var searchData=
[
  ['updateteam',['updateTeam',['../class_database.html#a561583878b8db60b3f00c82a770d62ee',1,'Database']]]
];
