var searchData=
[
  ['ui_5fmainwindow',['Ui_MainWindow',['../class_ui___main_window.html',1,'']]],
  ['updateteam',['updateTeam',['../class_database.html#a561583878b8db60b3f00c82a770d62ee',1,'Database']]]
];
