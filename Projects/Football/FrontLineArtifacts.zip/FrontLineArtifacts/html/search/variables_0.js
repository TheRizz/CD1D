var searchData=
[
  ['root',['root',['../classbinary_tree_type.html#aa05510bef44a62804a67445a448e5c93',1,'binaryTreeType']]]
];
